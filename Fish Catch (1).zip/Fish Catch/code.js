var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["34a2dc85-8216-4d95-a9b8-bd9a780e80ab","75bb3cb7-fae9-4dc3-b130-32edd39a7a39"],"propsByKey":{"34a2dc85-8216-4d95-a9b8-bd9a780e80ab":{"name":"fish","sourceUrl":null,"frameSize":{"x":128,"y":128},"frameCount":1,"looping":true,"frameDelay":12,"version":"D3Gt_cWj0Rf1rhnw8SfbQrdQIg89050K","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":128,"y":128},"rootRelativePath":"assets/34a2dc85-8216-4d95-a9b8-bd9a780e80ab.png"},"75bb3cb7-fae9-4dc3-b130-32edd39a7a39":{"name":"penguin","sourceUrl":"assets/api/v1/animation-library/gamelab/8y4kSh_oP_OP65gudXB1X7vAQ9EmTK72/category_animals/cuteanimals_penguin.png","frameSize":{"x":364,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"8y4kSh_oP_OP65gudXB1X7vAQ9EmTK72","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":364,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/8y4kSh_oP_OP65gudXB1X7vAQ9EmTK72/category_animals/cuteanimals_penguin.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var fish = createSprite(200, -55);
var penguin = createSprite(200, 360);
var score = 0;

penguin.setAnimation("penguin");
penguin.scale = 0.3;

fish.setAnimation("fish");
fish.scale = 0.5;
fish.velocityY = 1;

function draw() {
background("blue");
fish.velocityY = fish.velocityY + 0.5;

if (keyDown("LEFT_ARROW")){
penguin.x = penguin.x - 2;
}
if (keyDown("RIGHT_ARROW")){
penguin.x = penguin.x + 2;
}
if (fish.y > 425) {
  fishrest();
  fish.velocityY = fish.velocityY + 0.3;
}
  if(fish.isTouching(penguin)){
  score = score +1;
    fishrest();
  }
  fill("white");
   textSize(20);
  text("Score: " + score, 10, 10, 100, 100);
  
  drawSprites();
  
  if (score == 15) {
  textSize(50);
  textAlign(CENTER, CENTER);
  text("WINNER", 200, 200);
}


}




function fishrest() {
  fish.x = randomNumber(20, 380);
  fish.y = -10;
  fish.velocityY = 1;
}



// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
